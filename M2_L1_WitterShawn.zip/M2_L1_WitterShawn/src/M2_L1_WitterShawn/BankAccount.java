package M2_L1_WitterShawn;

public class BankAccount 
{
    private double balance; //Account Balance
    
    /**
     * This constructor sets the starting balance
     * at 0.0.
     */
    
    public BankAccount()
    {
        balance = 0.0;
    }
    
    /**
     * Copy constructor account accepts a
     * reference to another BankAccount object. The
     * object that is constructed is a copy of the 
     * argument object
     * @param obj A reference to a bank account object.
     */
    
    public BankAccount(BankAccount obj)
    {
        balance = obj.balance;
    }
    
    /**
     * This constructor sets the starting balance
     * to the value passed as an argument.
     * @param startBalance The starting balance
     */
    
    public BankAccount(double startBalance)
    {
        balance = startBalance;
    }
    
    /**
     * This constructor sets the starting balance
     * to the value in the string argument.
     * @param str
     */
    
    public BankAccount(String str)
    {
        balance = Double.parseDouble(str);
    }
    
    /**
     * The deposit method makes a deposit into the account
     * @param amount the amount to add to the balance field.
     */
    
    public void deposit(double amount)
    {
        balance += amount;
    }
    
    /**
     * The deposit method makes a deposit into the account
     * @param str the amount to add to the balance field,
     *  as a string 
     */
    
    public void deposit(String str)
    {
        balance += Double.parseDouble(str);
    }
    
    /**
     * The withdraw method makes a withdraw from the account
     * @param amount the amount to subtract from the balance field.
     */
    
    public void withdraw(double amount)
    {
        balance -= amount;
    }
    
    /**
     * The withdraw method makes a withdraw from the account
     * @param str the amount to subtract from the balance field,
     * as a string.
     */
    
    public void withdraw(String str)
    {
        balance -= Double.parseDouble(str);
    }
    
    /**
     * The setBalance method sets the account balance.
     * @param b the value to store in the balance field.
     */
    
    public void setBalance(double b)
    {
        balance = b;
    }
    
    /**
     * The setBalance method sets the account balance.
     * @param str the value, as a string, to store in the 
     * balance field,
     */
    
    public void setBalance(String str)
    {
        balance = Double.parseDouble(str);
    }
    
    /**
     * the getBalance method returns the account balance.
     * @return The value in the balance field.
     */
    
    public double getBalance()
    {
        return balance;
    }
}
