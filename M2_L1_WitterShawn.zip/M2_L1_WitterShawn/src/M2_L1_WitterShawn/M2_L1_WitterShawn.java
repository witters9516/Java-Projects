/**
* This program creates multiple bank accounts by using different constructors.
* 9/6/17
* CSC 251 Lab 7 - BankAccount Class Copy Constructor
* @author Shawn Witter
*/
package M2_L1_WitterShawn;

import java.text.DecimalFormat;

public class M2_L1_WitterShawn 
{
    public static void main(String[] args) 
    {
       //Create a BankAccount object with a
       //balance of $1,200.00
       BankAccount account1 = new BankAccount(1200.0);
       
       //Create anohter Bankaccount object as a
       //copy of the first.
       BankAccount account2 = new BankAccount(account1);
       
       //Create a DecimalFormat object to format
       //The balance when displayed.
       DecimalFormat dollar = new DecimalFormat("#,##0.00");
       
       //Display the balance in each amount.
       System.out.println("The balance in account #1 is $" +
               dollar.format(account1.getBalance()));
       System.out.println("The balance in account #2 is $" +
               dollar.format(account2.getBalance()));
    }
    
}
