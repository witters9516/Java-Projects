package m3_l5_wittershawn;

public class InvalidPayRate extends Exception
{
    /**
     * Constructor
     */
    public InvalidPayRate()
    {
        super("ERROR: Negative pay rate.");
    }
}
