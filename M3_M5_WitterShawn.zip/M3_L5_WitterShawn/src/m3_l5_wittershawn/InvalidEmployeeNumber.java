package m3_l5_wittershawn;

public class InvalidEmployeeNumber extends Exception
{
    /**
     * Constructor
     */
    public InvalidEmployeeNumber()
    {
        super("ERROR: Invalid employee number.");
    }
}
