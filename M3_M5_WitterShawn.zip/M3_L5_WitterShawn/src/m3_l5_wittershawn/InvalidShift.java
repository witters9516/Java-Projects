/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m3_l5_wittershawn;

/**
 *
 * @author witters9516
 */
public class InvalidShift extends Exception
{
    /**
     * Constructor
     */
    public InvalidShift()
    {
        super("ERROR: Invalid shift number.");
    }
}
