package m3_l4_wittershawn;

public class PassFailActivity extends GradedActivity
{
    private double minPassingScore; //minimum passing score
    
    /**
     * The Constructor sets the minimum passing score.
     * @param mps The minimum passing Score.
     */
    
    public PassFailActivity(double mps)
    {
        minPassingScore = mps;
    }
    
    /**
     * The getGrade method returns a letter grade
     * determined from the score field. This
     * method overrides the superclass method
     */
    
    @Override
    public char getGrade()
    {
        char letterGrade;
        
        if(super.getScore() >= minPassingScore)
            letterGrade = 'P';
        else
            letterGrade = 'F';
        
        return letterGrade;
    }
}
