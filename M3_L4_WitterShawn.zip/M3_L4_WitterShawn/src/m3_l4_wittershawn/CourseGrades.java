package m3_l4_wittershawn;

public class CourseGrades 
{
    //Variables
    final int SIZE = 4;
    GradedActivity[] grades = new GradedActivity[SIZE];
    
    //The setLab method accepts a GradedActivity object as an argument.
    //The method sets the object to index 0.
    public void setLab(GradedActivity obj)
    {
        grades[0] = obj;
    }
    
    //The setPassFailExam method accepts a PassFailExam object as an argument.
    //The method sets the object to index 1.
    public void setPassFailExam(PassFailExam obj)
    {
        grades[1] = obj;
    }
    
    //The setEssay method accepts a GradedActivity object as an argument.
    //The method sets the object to index 2.
    public void setEssay(GradedActivity obj)
    {
        grades[2] = obj;
    }
    
    //The setFinalExam method accepts a FinalExam object as an argument.
    //The method sets the object to index 3.
    public void setFinalExam(FinalExam obj)
    {
        grades[3] = obj;
    }
    
    //The toString method returns the contents of grades to the console.
    //@return index 1-4 scores.
    public String toString()
    {
       String output = "\nCourse Grades:";
        
       for(int i = 0; i < grades.length; i++)
       {
           output += "\n";
           if(i == 0)
                output += "Lab: " + grades[i].getScore();
           else if(i == 1)
                output += "PassFailExam: " + grades[i].getScore();
           else if(i == 2)
                output += "Essay: " + grades[i].getScore();
           else if(i == 3)
                output += "Final Exam: " + grades[i].getScore();
       }
        
       return output;
    }
}
