/**
* This program demonstrates inheritance by creating multiple types of graded assignments.
* 10/25/17
* CSC 251 Homework 3 - Course Grades
* Shawn Witter
*/

package m3_l4_wittershawn;

import java.util.Scanner;

public class M3_L4_WitterShawn 
{
    public static void main(String[] args) 
    {
        //Variables
        int labGrade;
        int PFEquestions;
        int PFEmissed;
        double PFEminPassingScore;
        int essayGrade;
        int FEquestions;
        int FEmissed;
        
        //Create a Scanner
        Scanner keyboard = new Scanner(System.in);
        
        //Create a CourseGrades object.
        CourseGrades grades1 = new CourseGrades();
        
        //1.What is the grade for the Lab?
        System.out.print("For the Lab, what score did the student get:\t");
        labGrade = Integer.parseInt(keyboard.next());
        
        //Create a new GradedActivity object
        GradedActivity lab = new GradedActivity();
        lab.setScore(labGrade);
        
        //set the lab to index 0.
        grades1.setLab(lab);
        
        //2.For the PassFailExam, How Many Questions?
        System.out.print("\nFor the PassFailExam, how many questions were on the exam:\t");
        PFEquestions = Integer.parseInt(keyboard.next());
        //3.For the PassFailExam, How Many Missed?
        System.out.print("\nFor the PassFailExam, how many questions on the exam did the student miss:\t");
        PFEmissed = Integer.parseInt(keyboard.next());
        //4.For the PassFailExam, What is the minimum Passign score?
        System.out.print("\nFor the PassFailExam, what is the minimum passing score for this exam:\t");
        PFEminPassingScore = Double.parseDouble(keyboard.next());
        
        //Create a new GradedActivity object
        PassFailExam pfExam = new PassFailExam(PFEquestions, PFEmissed, PFEminPassingScore);
        
        //set the pfExam to index 1.
        grades1.setPassFailExam(pfExam);
        
        
        //5.What is the grade for the essay?
        System.out.print("\nFor the Essay, what score did the student get:\t");
        essayGrade = Integer.parseInt(keyboard.next());
        
        //Create a new GradedActivity object
        GradedActivity essay = new GradedActivity();
        essay.setScore(essayGrade);
        
        //set the essay to index 2.
        grades1.setEssay(essay);
        
        //6.For the FinalExam, How many questions?
        System.out.print("\nFor the FinalExam, how many questions were on the exam:\t");
        FEquestions = Integer.parseInt(keyboard.next());
        //7.For the FinalExam, How many missed?
        System.out.print("\nFor the FinalExam, how many questions did the student miss:\t");
        FEmissed = Integer.parseInt(keyboard.next());
        
        //Create a new GradedActivity object
        FinalExam fExam = new FinalExam(FEquestions, FEmissed);
        
        //set the essay to index 2.
        grades1.setFinalExam(fExam);

        System.out.print(grades1.toString());
    }
}