/**
* This program can capitilizes sentences by tokenizing.
* 10/5/17
* CSC 251 Lab 8 - Sentence Capitalizer 
* @author Shawn Witter
*/

package M3_L1_ShawnWitter;

import java.util.Scanner;

public class M3_L1_ShawnWitter 
{
    public static void main(String[] args) 
    {
        //Create a Scanner
        Scanner keyboard = new Scanner(System.in);
        
        //Variables
        String input;
        String output;
        
        //Prompt user input.
        System.out.print("Please Type a sentence or two:\t");
        //Take input
        input = keyboard.nextLine();
        
        //Print input
        System.out.println("Input:\t" + input);
        
        //Set output to Capitilizer
        output = Capitilizer(input);
        
        //Print output
        System.out.println("Output:\t" + output);
    }
    
    //The Capitilizer method takes a String as an argument. This method
    //splits a string of sentences into an array of sentences. It then uses
    //another method to capitilize each sentence.
    public static String Capitilizer(String sentences)
    {
        //Variables
        String outStr = "";
        String delim = "\\.";
        String[] sentenceArray = sentences.split(delim);

        //Steps through the array and capitilizes each sentence.
        for(int i = 0; i < sentenceArray.length; i++)
        {
            sentenceArray[i] = sentenceArray[i].trim();
            sentenceArray[i] = CapitilizeWord(sentenceArray[i]);
            outStr += sentenceArray[i] + ". ";
        }

        //Return outstring.
        return outStr;
    }
    
    //The CapitilizeWord method takes a String as an argument. This method
    //Creates a character array from the argument given and then converts the 
    //first letter of each sentence.
    public static String CapitilizeWord(String word)
    {
        //variables
        char[] array = word.toCharArray();  //send word into a character array.
        String returnWord = "";             //string accumulator.
   
        //set the first character to the uppercase equivalent.
        array[0] = Character.toUpperCase(array[0]);

        //creates new string using a loop.
        for (int i = 0; i < array.length; i++)
            returnWord += Character.toString(array[i]);

        //return new string.
        return returnWord;
    }
}
