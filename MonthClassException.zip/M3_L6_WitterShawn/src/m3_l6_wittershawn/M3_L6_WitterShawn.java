/**
* This project demonstrates throwing exceptions when invalid data is sent into
* month objects.
* 11/6/2017
* CSC 251 Homework 4 - Month Class Exceptions
* Shawn Witter
*/
package m3_l6_wittershawn;

public class M3_L6_WitterShawn 
{
    public static void main(String[] args) 
    {
        //Create a Month object by Name with valid data
        System.out.println("Attempting a valid month number...");
        CreateMonthByName("february");
        
        //Try to use an invalid month name.
        System.out.println();
        System.out.println("Attempting an invalid month name...");
        CreateMonthByName("asdf");
        
        //Create a Month object by Number with valid data
        System.out.println();
        System.out.println("Attempting a valid month number...");
        CreateMonthByNumber(3);
        
        //Try to use an invalid month number.
        System.out.println();
        System.out.println("Attempting an invalid month number...");
        CreateMonthByNumber(13);
    }
    
    public static void CreateMonthByName(String monthName)
    {
        try
        {
            //Create a temporary month object
            Month temp = new Month(monthName);
            
            //If we make it to this point, the object was successfully created.
            System.out.println("Object created:");
            System.out.println(temp);
        }
        catch(InvalidMonthName e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    public static void CreateMonthByNumber(int monthNumber)
    {
        try
        {
            //Create a temporary month object
            Month temp = new Month(monthNumber);
            
            //If we make it to this point, the object was successfully created.
            System.out.println("Object created:");
            System.out.println(temp);
        }
        catch(InvalidMonthNumber e)
        {
            System.out.println(e.getMessage());
        }
    }
}
