package m3_l6_wittershawn;

public class InvalidMonthName extends Exception
{
    public InvalidMonthName()
    {
        super("ERROR: Invalid month name.");
    }
}
