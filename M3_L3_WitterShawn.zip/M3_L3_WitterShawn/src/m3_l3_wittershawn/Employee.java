package m3_l3_wittershawn;

public class Employee 
{
    private String name;            //Employee Name
    private String employeeNumber;  //Employee Number
    private String hireDate;        //Employee Hire Date
    
    /**
     * This constructor initializes an object with a name,
     * employee number, and hire date.
     * @param n The employee's name.
     * @param num The employee's number.
     * @param date The employee's hire date.
     */
    
    public Employee(String n, String num, String date)
    {
        name = n;
        setEmployeeNumber(num);
        hireDate = date;
    }
    
    /**
     * The no-arg constructor initializes an object with 
     * null strings for name, employee number, and hire 
     * date.
     */
    
    public Employee()
    {
        name = "";
        employeeNumber = "";
        hireDate = "";
    }
    
    /**
     * The setName method sets the employee's name.
     * @param n The employee's name.
     */
    
    public void setName(String n)
    {
        name = n;
    }
    
    /**
     * The setEmployeeNumber method sets the employee's
     * number.
     * @param e The employee's number.
     */
    
    public void setEmployeeNumber(String e)
    {
        if(isValidEmpNum(e))
            employeeNumber = e;
        else
            employeeNumber = "";
    }
    
    /**
     * The setHireDate method stes the employee's
     * hireDate.
     * @param h The employee's hire date.
     */
    
    public void setHireDate(String h)
    {
        hireDate = h;
    }
    
    /**
     * The getName method returns the employee's name.
     * @return The employee's name.
     */
    
    public String getName()
    {
        return name;
    }
    
    /**
     * The getEmployeeNumber method returns the
     * employee's number.
     * @return The Employee's number.
     */
    
    public String getEmployeeNumber()
    {
        return employeeNumber;
    }
    
    /**
     * isValidEmpNum method is a private method that
     * determines whether a string is a valid
     * employee number.
     * @param e The string containing an employee
     * number.
     * @return true if e reference a valid ID Number.
     * false, otherwise.
     */
    
    private boolean isValidEmpNum(String e)
    {
        boolean status = true;
        
        if(e.length() != 5)
            status = false; 
        else
        {
            if((!Character.isDigit(e.charAt(0))) ||
            (!Character.isDigit(e.charAt(1))) ||
            (!Character.isDigit(e.charAt(2))) ||
            (e.charAt(3) != '-') ||
            (Character.toUpperCase(e.charAt(4)) < 'A') ||
            (Character.toUpperCase(e.charAt(4)) > 'M'))
                status = false;
        }
        
        return status;
    }
    
    /**
     * toString Method
     * @param A reference to a string representation of
     * the object.
     */
    
    public String toString()
    {
        String str = "Name: " + name + " Employee Number: ";
        
        if(employeeNumber == "")
            str += "INVALID EMPLOYEE NUMBER";
        else
            str += employeeNumber;
        
        str += ("\n Hire Date: " + hireDate);
        
        return str;
    }
}
