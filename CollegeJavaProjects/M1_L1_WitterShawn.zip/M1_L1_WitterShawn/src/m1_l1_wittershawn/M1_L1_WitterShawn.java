/*
 * A brief description of the project
 * 8/23/2017
 * CSC 251 Lab 1 - Miles Per Gallon
 * @author witters9516
 */

package m1_l1_wittershawn;
import javax.swing.JOptionPane;

public class M1_L1_WitterShawn //Miles Per Gallon
{
    public static void main(String[] args) 
    {
        //Variables
	String inputString;
        double milesDriven;             //Miles Driven
	double gallonsOfGasUsed;	//Gallons Used
	double MPG;			//Miles-Per-Gallon    }
    
        //Input string and store into miles driven as double.
	inputString = JOptionPane.showInputDialog("How many miles did you drive? ");
	milesDriven = Double.parseDouble(inputString);
	
        //Input string and store into gallonsUsed as double.
        inputString = JOptionPane.showInputDialog("How many gallons of gas did you use? ");
	gallonsOfGasUsed = Double.parseDouble(inputString);
	
        //Calculate MPG
        MPG = milesDriven / gallonsOfGasUsed;

        //Display Results
	JOptionPane.showMessageDialog(null, "Your current MPG is " + MPG);
    }
}
