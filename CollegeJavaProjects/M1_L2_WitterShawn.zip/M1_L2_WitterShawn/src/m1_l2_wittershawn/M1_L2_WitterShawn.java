/**
 * A brief description of the project
 * 8/23/2017
 * CSC 251 Lab 2 - Time Calculator
 * @author witters9516
 */

package m1_l2_wittershawn;
import javax.swing.JOptionPane;

public class M1_L2_WitterShawn 
{
    public static void main(String[] args) 
    {
        //Variables
	String inputString;
	double seconds;
	double minutes;
	double hours;
	double days;
        
        //Input string and store into seconds as int and bill as a double.
	inputString = JOptionPane.showInputDialog("Enter any number of seconds?");
	seconds = Double.parseDouble(inputString);

	//Determine seconds and Calculate amount of time it is equivalent to. then displays to screen.
        if(seconds >= 86400)
	{
		days = seconds / 86400;
		JOptionPane.showMessageDialog(null, days + " days is equal to " + seconds + " seconds.\n");
	}
        else if(seconds >= 3600)
	{
		hours = seconds / 3600;
		JOptionPane.showMessageDialog(null, hours + " hours is equal to " + seconds + " seconds.\n");
	}
        else if(seconds >= 60)
	{
		minutes = seconds / 60;
		JOptionPane.showMessageDialog(null, minutes + " minutes is equal to " + seconds + " seconds.\n");
	}
	else
	{
		JOptionPane.showMessageDialog(null, "There is no equivalent to this amount of seconds.");
	}
    }
}
