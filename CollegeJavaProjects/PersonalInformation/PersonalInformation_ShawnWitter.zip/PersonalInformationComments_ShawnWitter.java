PERSON CLASS
//Create the person class
	//Variables
		//A person's name
		//A person's address
		//A person's age
		//A person's phone number

	//The no-arg constructor initializes an empty object.
	
	//Th parameterized constructor accepts arguments for the objects fields.
		//@param myName	A person's name
		//@param myAddress	A person's address
		//@param myAge	A person's age
		//@param myPhone	A person's phone number

	//The setName method sets the person's name
		//@param myName - the person's name
	
	//The setAddress method sets the person's address
		//@param myAddress - the person's address
	
	//The setAge method sets the person's age
		//@param myAge - the person's age
	
	//The setPhone method sets the person's phone number
		//@param myPhone - the person's phone number

	//The getName method returns the person's name
		//@Return the person's name
	
	//The getAddress method returns the person's address
		//@Return the person's address
	
	//The getAge method returns the person's age
		//@Return the person's age
	
	//The getPhone method returns the person's phone number
		//@Return the person's phone
	
PERSONAL INFORMATION

//Create the Objects
		//Set my info
		//Set Friend 1's info
		//Set Friend 2's info
		//Display my info
		//Display Friend 1 info
		//Display Friend 2 info
