package m3_l2_wittershawn;

public class PasswordValidator 
{
    private final int MIN_LENGTH = 6;   //Password minimum length
    String password;                    //Password field. Used for validation.
    
    /**
     * The PasswordValidator sets the password field to a null string.
     */
    public PasswordValidator()
    {
        password = "";
    }
    
    /**
     * The PasswordValidator takes a string as an argument.
     * The value of the str string is set to the password field.
     * @param str - the password.
     */
    public PasswordValidator(String str)
    {
        password = str;
    }
    
    //The checkForUpperCase method accepts a string as an argument
    //and returns the number of uppercase letters it contains.
    public int checkForUpperCase(String str)
    {
        int upperCase = 0;  //The number of uppercase letters
        
        char[] chArray = str.toCharArray();
        //Count the uppercase characters in str
        for(int i = 0; i < chArray.length; i++)
            if (Character.isUpperCase(chArray[i]))
                upperCase++;

        //Return the number of uppercase characters.
        return upperCase;
    }

    //The checkForLowerCase method accepts a string argument
    // and returns the number of lowercase letters it contains.
    public int checkForLowerCase(String str)
    {
        int lowerCase = 0;  //The number of lowerCase letters

        char[] chArray = str.toCharArray();
        
        //Count the lowercase characters in str
        for(int i = 0; i < chArray.length; i++)
            if (Character.isLowerCase(chArray[i]))
                lowerCase++;

        //Return the number of lowerCase characters.
        return lowerCase;
    }

    //The checkForDigits method accepts a string argument
    // and returns the number of numeric digits it contains.
    public int checkForDigits(String str)
    {
        int digits = 0;  //The number of digits

        char[] chArray = str.toCharArray();
        
        //Count the lowercase characters in str
        for(int i = 0; i < chArray.length; i++)
            if (Character.isDigit(chArray[i]))
                digits++;

        //Return the number of digits.
        return digits;
    }
    
    public boolean validatePassword()
    {   
        //Validate the password
        if (password.length() >= MIN_LENGTH &&
            checkForUpperCase(password) >= 1 &&
            checkForLowerCase(password) >= 1 &&
            checkForDigits(password) >= 1)
            return true;
        else
            return false;
    }
}
