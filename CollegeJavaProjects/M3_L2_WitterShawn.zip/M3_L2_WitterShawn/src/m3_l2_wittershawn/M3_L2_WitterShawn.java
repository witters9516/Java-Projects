/**
* This program asks the user to input a password and then it creates an object 
* that will validate the password.
* 10/11/17
* CSC 251 Homework 2 - Password Verifier
* Shawn Witter
*/
package m3_l2_wittershawn;

import java.util.Scanner;

public class M3_L2_WitterShawn 
{
    public static void main(String[] args) 
    {
        //Create a scanner
        Scanner keyboard = new Scanner(System.in);
        
        //Get the password from the user
        System.out.println("Please input the password your would like to create "
                + "\nIt must be at least 6 characters long, contain at "
                + "least one uppercase and lowercase letter, and must contain "
                + "at least 1 digit.");
        
        //password is set to the input of the user
        String password = keyboard.next();

        //with the new password, create an object using the input as an argument.
        PasswordValidator newPassword = new PasswordValidator(password);
        
        //Check the password to make sure it is valid and tell the 
        //user if it is valid or not.        
        if(newPassword.validatePassword())
            System.out.println("The Password is valid.");
        else
            System.out.println("The password does not meet the requirements.");
    }
}
