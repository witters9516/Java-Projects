/**
 * This program prompts the user to enter a valid account number.
 * If the input is equal to any of the values in the class array, it says valid.
 * Anything else will say it is invalid.
 * 8/23/2017
 * CSC 251 Lab 6 - Charge Account Validation
 * @author witters9516
 */
package m1_l6_wittershawn;

import javax.swing.JOptionPane;

public class M1_L6_WitterShawn 
{
    public static void main(String[] args) 
    {
        String input;			//to Hold Keyboard Input
        int accountNumber;		//Account Number to Validate


        //Create Validator
        Validator val = new Validator();

        //Get a charge account number
        input = JOptionPane.showInputDialog("Enter your charge account number: ");
        accountNumber = Integer.parseInt(input);

        //Determine whether it is valid
        if(val.isValid(accountNumber))
                JOptionPane.showMessageDialog(null, "That's a valid account number.");
        else
                JOptionPane.showMessageDialog(null, "That's a INVALID account number.");

        System.exit(0);
    }    
}
