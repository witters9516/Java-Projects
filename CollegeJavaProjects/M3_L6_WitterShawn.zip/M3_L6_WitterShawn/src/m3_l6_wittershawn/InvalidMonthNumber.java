package m3_l6_wittershawn;

public class InvalidMonthNumber extends Exception
{
    public InvalidMonthNumber()
    {
        super("ERROR: Invalid month number.");
    }
}
