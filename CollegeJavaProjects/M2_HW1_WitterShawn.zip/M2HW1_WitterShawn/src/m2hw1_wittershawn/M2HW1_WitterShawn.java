/**
* This program creates objects using different constructors and then 
* compares their values.
* 9/11/17
* CSC 251 Homework 1 - Month Class
* @author Shawn Witter
*/
package m2hw1_wittershawn;

public class M2HW1_WitterShawn 
{
    public static void main(String[] args) 
    {
        //Create object instances using the 3 constructors.
        Month monthCon1 = new Month();
        Month monthCon2 = new Month(1);
        Month month1 = new Month("January");
        Month month2 = new Month("February");
        Month month3 = new Month("March");
        Month month4 = new Month("April");
        Month month5 = new Month("May");
        Month month6 = new Month("June");
        Month month7 = new Month("July");
        Month month8 = new Month("August");
        Month month9 = new Month("September");
        Month month10 = new Month("October");
        Month month11 = new Month("November");
        Month month12 = new Month("December");

        //Print Information contained in each object to the console.
        printDataInfo(monthCon1);
        printDataInfo(monthCon2);
        printDataInfo(month1);
        printDataInfo(month2);
        printDataInfo(month3);
        printDataInfo(month4);
        printDataInfo(month5);
        printDataInfo(month6);
        printDataInfo(month7);
        printDataInfo(month8);
        printDataInfo(month9);
        printDataInfo(month10);
        printDataInfo(month11);
        printDataInfo(month12);

        //Compare 2 months 4 times to see whether or not the objects are equal 
        //to, greater than, and less than each other.
        compareTwoMonths(month1, month2);
        compareTwoMonths(month1, month4);
        compareTwoMonths(month4, month5);
        compareTwoMonths(month5, month4);

    }
    
    //The printDataInfo accepts a Month obj as an argument. It returns a string 
    //that includes the month number and name.
    public static void printDataInfo(Month month)
    {
        System.out.println("Month " + month.getMonthNumber() + " is " + month.getMonthName() + ".");
    }
    
    //The compareTwoMonths accepts 2 month objs as arguments. It compares the 
    //two objects and prints out whether they are equal, if one is greater than,
    //or less than each other.
    public static void compareTwoMonths(Month monthOne, Month monthTwo)
    {
        if(monthOne.equals(monthTwo))
            System.out.println(monthOne.getMonthName() + " is equal to " + monthTwo.getMonthName() + ".");
        else
            System.out.println(monthOne.getMonthName() + " is not equal to " + monthTwo.getMonthName() + ".");

        if(monthOne.greaterThan(monthTwo))
            System.out.println(monthOne.getMonthName() + " is greater than " + monthTwo.getMonthName() + ".");
        else
            System.out.println(monthOne.getMonthName() + " is not greater than " + monthTwo.getMonthName() + ".");
        
        if(monthOne.lessThan(monthTwo))
            System.out.println(monthOne.getMonthName() + " is less than " + monthTwo.getMonthName() + ".");
        else
            System.out.println(monthOne.getMonthName() + " is not less than " + monthTwo.getMonthName() + ".");
    }
}
