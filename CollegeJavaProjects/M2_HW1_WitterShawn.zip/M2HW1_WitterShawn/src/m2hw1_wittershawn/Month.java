package m2hw1_wittershawn;

public class Month 
{
    //Variables
    int _monthNumber;
    
    //The Month Constructor sets _monthNumber to 1.
    public Month()
    {
        _monthNumber = 1;
    }
    
    //The Month Constructor takes an int as an arguments and sets _monthNumber 
    //to that integer value.
    public Month(int monthNumber)
    {
        _monthNumber = monthNumber;
    }
    
    //The Month Constructor takes an string as an arguments and sets 
    //_monthNumber to that string value using a conditional statement.
    public Month(String monthName)
    {
        monthName = monthName.toLowerCase();
        
        if (monthName.equals("january"))
            _monthNumber = 1;
        else if (monthName.equals("february"))
            _monthNumber = 2;
        else if (monthName.equals("march"))
            _monthNumber = 3;
        else if (monthName.equals("april"))
            _monthNumber = 4;
        else if (monthName.equals("may"))
            _monthNumber = 5;
        else if (monthName.equals("june"))
            _monthNumber = 6;
        else if (monthName.equals("july"))
            _monthNumber = 7;
        else if (monthName.equals("august"))
            _monthNumber = 8;
        else if (monthName.equals("september"))
            _monthNumber = 9;
        else if (monthName.equals("october"))
            _monthNumber = 10;
        else if (monthName.equals("november"))
            _monthNumber = 11;
        else if (monthName.equals("december"))
            _monthNumber = 12;
        else
            _monthNumber = 1;
    }
    
    //The setMonthNumber method takes an int as an argument. It sets 
    //_monthNumber to the int value and if teh value is less than 1 
    //or greater than 12, it sets _monthNumber to 1.
    public void setMonthNumber(int number)
    {
        _monthNumber = number;
        
        if (_monthNumber > 12 || _monthNumber < 1)
            _monthNumber = 1;
    }
    
    //The getMonthNumber returns _monthNumber to the user.
    public int getMonthNumber()
    {
        return _monthNumber;
    }
    
    //The getMonthName returns a string to the user based on the _monthNumber.
    //ex: "January" = 1, ect.
    public String getMonthName()
    {
        String monthName;
        switch(_monthNumber)
        {
            case 1:
                monthName = "January";
                break;
            case 2:
                monthName = "February";
                break;
            case 3:
                monthName = "March";
                break;
            case 4:
                monthName = "April";
                break;
            case 5:
                monthName = "May";
                break;
            case 6:
                monthName = "June";
                break;
            case 7:
                monthName = "July";
                break;
            case 8:
                monthName = "August";
                break;
            case 9:
                monthName = "September";
                break;
            case 10:
                monthName = "October";
                break;
            case 11:
                monthName = "November";
                break;
            case 12:
                monthName = "December";
                break;
            default:
                monthName = "";
                break;
        }  
        return monthName;
    }
    
    //the toString method returns the getMonthName method as a string.
    public String toString()
    {
        return getMonthName();
    }
    
    //The equals method take a Month obj as an argument. If the _monthNumber of
    //both objects is the same, it returns true. otherwise, false.
    public boolean equals(Month month)
    {
        if(month.getMonthNumber() == this.getMonthNumber())
            return true;
        else
            return false;
    }
    
    //The greaterThan method take a Month obj as an argument. If the _monthNumber of
    //the first object is greater than the second object, it returns true. 
    //otherwise, false.
    public boolean greaterThan(Month monthObj)
    {
        if(this._monthNumber > monthObj._monthNumber)
            return true;
        else
            return false;
    }
    
    //The lessThan method take a Month obj as an argument. If the _monthNumber of
    //the first object is less than the second object, it returns true. 
    //otherwise, false.
    public boolean lessThan(Month monthObj)
    {
        if(this._monthNumber < monthObj._monthNumber)
            return true;
        else
            return false;
    }
}
