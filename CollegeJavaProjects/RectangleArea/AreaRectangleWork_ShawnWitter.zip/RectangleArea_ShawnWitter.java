/**
* This program uses fuctions to calculate the area of the a rectangle
* 4/10/17
* CSC 151 Homework 5 - Rectangle Area - Complete the Program
* Shawn Witter
*/

// Insert any necessary import statements here.
import javax.swing.*;

public class RectangleArea_ShawnWitter

{
   public static void main(String[] args)
   {
      double length;    // The rectangle's length
      double width;     // The rectangle's width
      double area;      // The rectangle's area

      // Get the rectangle's length from the user.
      length = getLength();

      // Get the rectangle's width from the user.
      width = getWidth();

      // Get the rectangle's area.
      area = getArea(length, width);

      // Display the rectangle data.
      displayData(length, width, area);
   }

   public static double getLength()
   {
	   //Temp variables
	   String temp1;
	   double temp2;

	   //Ask for input and parses it to a float
	   temp1 = JOptionPane.showInputDialog("What is the length of the Rectangle:\t");
	   temp2 = Double.parseDouble(temp1);

	   //Return float
	   return temp2;
   }


   public static double getWidth()
   {
	   //Temp variables
   	   String temp1;
   	   double temp2;

   	   //Ask for input and parses it to a float
	   temp1 = JOptionPane.showInputDialog("What is the width of the Rectangle:\t");
	   temp2 = Double.parseDouble(temp1);

	   //Return Float
	   return temp2;
   }

   public static double getArea(double length, double width)
   {
	   //Calculate area
   	   double area = length * width;
   	   //Return area
   	   return area;
   }

   public static void displayData(double length, double width, double area)
   {
	   //Display Data to the screen.
       JOptionPane.showMessageDialog(null, "With a length of " + length + " and a width of " +
       			width + ", this rectangle has an area of " + area + ".");

   }
}
