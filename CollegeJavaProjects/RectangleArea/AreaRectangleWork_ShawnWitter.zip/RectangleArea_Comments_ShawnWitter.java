/**
* This program uses fuctions to calculate the area of the a rectangle
* 4-10-17
* CSC 151 Homework 5 - Rectangle Area - Complete the Program
* Shawn Witter
*/

// Insert any necessary import statements here.
//javax import statement

	//Main method
		//Variables
      		// The rectangle's length
      		// The rectangle's width
      		// The rectangle's area

      // Get the rectangle's length from the user.
      	//Call getLength

      // Get the rectangle's width from the user.
      	//Call getWidth

      // Get the rectangle's area.
      	//Call getArea

      // Display the rectangle data.
      	//Call displayData

	//getLength Method
	   //Temp variables
	   		//Temp variable to hold question
	   		//Temp to parse the question as a double
	   //Ask for input and parses it to a float
	   //Return float for length

	//getWidth Method
	   //Temp variables
	   		//Temp variable to hold question
	   		//Temp to parse the question as a double
   	   //Ask for input and parses it to a float
	   //Return Float for width

	//getArea Method (accepts length and width as arguments)
	   //Calculate area (length * width)
   	   //Return area

	//displayData Method
	   //Display Data to the screen.

//Comments regarding the start file
/*
-There were a lot of mistakes in the start file at the beginning.
-They consisted of mostly syntax errors involving commas and semi colons.
-After fixing those, I added the inport statement for the joption Pane
-Next I built the 4 functions listed in the book, putting parameters where needed.
*/