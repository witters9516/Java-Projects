package m1_l5_wittershawn;

public class Person 
{
    //Variables
    private String myName;	//Employee's name
    private String myAddress;	//ID Number
    private int myAge;          //Hourly Pay Rate
    private String myPhone;	//Number of Hours Worked
    
    public Person()
    {
        myName = "";
        myAddress = "";
        myAge = 0;
        myPhone = "";
    }
    
    //Th parameterized constructor accepts arguments for the objects fields.
        //@param myName 	A person's name
        //@param myAddress	A person's address
        //@param myAge          A person's age
        //@param myPhone	A person's phone number

    public Person(String personName, String personAddress, int personAge, String personPhone)
    {
        myName = personName;
        myAddress = personAddress;
        myAge = personAge;
        myPhone = personPhone;
    }

    //Setters
    //The setName method sets the person's name
        //@param myName - the person's name
    public void setName(String name)
    {
        myName = name;
    }
    //The setAddress method sets the person's address
        //@param myAddress - the person's address
    public void setAddress(String address)
    {
        myAddress = address;
    }
    //The setAge method sets the person's age
            //@param myAge - the person's age
    public void setAge(int age)
    {
        myAge = age;
    }
    //The setPhone method sets the person's phone number
            //@param myPhone - the person's phone number
    public void setPhone(String phone)
    {
        myPhone = phone;
    }

    //Getters
    //The getName method returns the person's name
            //@Return the person's name
    public String getName()
    {
        return myName;
    }
    //The getAddress method returns the person's address
            //@Return the person's address
    public String getAddress()
    {
        return myAddress;
    }
    //The getAge method returns the person's age
            //@Return the person's age
    public int getAge()
    {
        return myAge;
    }
    //The getPhone method returns the person's phone number
            //@Return the person's phone
    public String getPhone()
    {
        return myPhone;
    }
}
