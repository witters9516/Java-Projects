/**
* This project demonstrates the usage of the JOptionPane and GUI.
* Date
* CSC 251 Lab 12 - Monthly Sales Tax
* Shawn Witter
*/
package monthlysalestax_shawnwitter;

import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class MonthlySalesTax_ShawnWitter extends JFrame
{
    private JPanel panel;           //A panel to hold everything
    private JTextField totalSales;  //To get total sales
    private JButton calcButton;     //Calculates everything
    
    //Constants for tax rates
    private final double COUNTY_RATE = 0.02;
    private final double STATE_RATE = 0.04;
    
    //Constants for window size
    private final int WINDOW_WIDTH = 360;
    private final int WINDOW_HEIGHT = 100;
    
    /**
     * Constructor
     */
    public MonthlySalesTax_ShawnWitter()
    {
        //Set the title.
        setTitle("Monthly Sales Tax Reporter");
        
        //Specify what happens when the close button is clicked.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Build the panel that contains the other components.
        buildPanel();
        
        //Add the panel to the content pane.
        add(panel);
        
        //Size and display the window.
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setVisible(true);
    }
    
    /**
     * The buildPanel method creates a panel containing
     * other components
     */
    
    private void buildPanel()
    {
        //Create a label prompting for the total sales.
        JLabel totalSalesMsg = new JLabel("Enter the total sales:");
        
        //Create a text field for total sales.
        totalSales = new JTextField(10);
        
        //Create a button to click.
        calcButton = new JButton("Calculate Sales Tax");
        
        //Add an action listener to the button.
        calcButton.addActionListener(new CalcButtonListener());
        
        //Create a panel.
        panel = new JPanel();
        
        //Add the label, text field, and button to the panel.
        panel.add(totalSalesMsg);
        panel.add(totalSales);
        panel.add(calcButton);
    }
    
    /**
     * CalcButtonListener is an action listener class for the 
     * calcButton component
     */
    private class CalcButtonListener implements ActionListener
    {
        /**
         * actionPerformed Method
         * @param e An ActionEvent object.
         */
        @Override
        public void actionPerformed(ActionEvent e)
        {
            double totalSalesAmount,        //To hold the sales amount
                    countyTaxAmount,        //To hold the county tax
                    stateTaxAmount,         //To hold the state tax
                    totalTaxAmount;         //To hold the total tax
            
            //Create a DecimalFormat object to format output.
            DecimalFormat dollar = new DecimalFormat("#,##0.00");
            
            //Get the total sales.
            totalSalesAmount = Double.parseDouble(totalSales.getText());
            
            //Calculate the county tax.
            countyTaxAmount = totalSalesAmount * COUNTY_RATE;
            
            //Calculate the state tax.
            stateTaxAmount = totalSalesAmount * STATE_RATE;
            
            //Calculate the total sales.
            totalTaxAmount = countyTaxAmount + stateTaxAmount;
            
            //Display the results.
            JOptionPane.showMessageDialog(null, "County Sales Tax: $" +
                    dollar.format(countyTaxAmount) +
                    "\nState Sales Tax: $" +
                    dollar.format(stateTaxAmount) +
                    "\nTotal Sales Tax: $" +
                    dollar.format(totalTaxAmount));
        }
    }
    
    /**
     * The main method creates an instance of the SalesTaxClass, 
     * causing it to display its window.
     */
    public static void main(String[] args)
    {
        MonthlySalesTax_ShawnWitter stv = new MonthlySalesTax_ShawnWitter();
                
        stv.setVisible(true);
        
    }
    
}
